const containerCards = document.getElementById("container-cards")


const title = document.createElement('h2')
const image = document.createElement('image')
const director = document.createElement('p')
const description = document.createElement('p')
const criarCard = document.createElement('div')

async function getCards() {
  try { 
      const resposta = await fetch('https://ghibliapi.herokuapp.com/films')
      const informacoes = await resposta.json()
      const criacao = informacoes.data()
      criacao.map((card) => {
      title.setAttribute('class', 'titulo')
      image.setAttribute('class', 'imagem')
      director.setAttribute('class', 'diretor')
      description.setAttribute('class', 'descrição')
      criarCard.setAttribute('class', 'div')
      title.innerText = card.title
      director.innerText = card.director
      description.innerText = card.description
      image.attributes('src', card.card_image[0].image_url)
      containerCards.appendChild(criarCard)
      criarCard.appendChild(image)
      criarCard.appendChild(title)
      criarCard.appendChild(director)
      criarCard.appendChild(description)
    })
  } 
  catch (error){
    console.error(error)
  }
}
getCards()

